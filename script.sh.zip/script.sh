mkdir assignment

cd assignment

touch README index.html main.js main.css deletme.txt

mkdir assets

mv main.js main.css assets

rm -r deletme.txt

echo 'The command line rules!' > index.html

ls -la > README